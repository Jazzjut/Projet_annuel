<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("init.php");
$req=$db->prepare("SELECT * FROM image WHERE id=? LIMIT 1");
// limit 1 car il y a qu'un seul enregistrment qui vas satisfaire cette condition
$req->setFetchMode(PDO::FETCH_ASSOC);
$req->execute(array($_GET["id"]));
$tab=$req->fetch();
// Vérifier si une image a été trouvée avec l'ID spécifié
if ($tab) {
    // Définir l'en-tête Content-Type pour indiquer qu'il s'agit d'une image
    header("Content-Type: image/jpeg"); // Changer le type d'image si nécessaire

    // Afficher les données binaires de l'image
    echo $tab["bin"];
} else {
    // Si aucune image n'est trouvée, afficher une image par défaut ou un message d'erreur
    echo "Image non trouvée";
}
?>
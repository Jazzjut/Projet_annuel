<?php
require_once("init.php"); // Assurez-vous d'inclure votre fichier d'initialisation
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if (isset($_POST['valider'])) {
    $formDemandeAID = $_SESSION['formDemandeAID'];
    $logement = $_SESSION['logement'];
    $adresse = $_SESSION['adresse'];
    $exterieur = $_SESSION['exterieur'];
    $nbHeure = $_SESSION['nbHeure'];
    $enfant = $_SESSION['enfant'];
    $motif = $_SESSION['motif'];
    $etat = 'en cours de traitement';

    $date = date("Y-m-d");

    // Préparation de la requête SQL
    $requete = "INSERT INTO FormDemandeA(formDemandeAID, Logement, Adresse, ext, nbHSeul, nbEnf, raisonDemandeA, dateDemandeA, etatDemandeA) 
                VALUES (:formDemandeAID, :logement, :adresse, :exterieur, :nbHeure, :enfant, :motif, :date, :etat)";
    $ajout = $db->prepare($requete);

    // Liaison des paramètres
    $ajout->bindParam(':formDemandeAID', $formDemandeAID);
    $ajout->bindParam(':logement', $logement);
    $ajout->bindParam(':adresse', $adresse);
    $ajout->bindParam(':exterieur', $exterieur);
    $ajout->bindParam(':nbHeure', $nbHeure);
    $ajout->bindParam(':enfant', $enfant);
    $ajout->bindParam(':motif', $motif);
    $ajout->bindParam(':etat', $etat);
    $ajout->bindParam(':date', $date);

    // Exécution de la requête
    if ($ajout->execute()) {
        echo "Demande d'adoption enregistrée avec succès.";
    } else {
        echo "Erreur lors de l'enregistrement de la demande d'adoption.";
    }
} elseif (isset($_POST['annuler'])) {
    // Si l'utilisateur clique sur "Annuler", ne rien faire
    header("Location: accueil.html");
}
// Fermeture de la connexion à la base de données
$db = null;

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Formulaire d'adoption</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <div class="container">
        <div class="partie-droite">
            <div class="formulaire">
                <form action="recapitulatif.php" method="post">
                    <h2>Formulaire d'adoption</h2>
                    <label for="logement">Logement :</label>
                    <select id="logement" name="logement" required>
                        <option value="" disabled selected>Choisissez le type de logement</option>
                        <option value="maison">Maison</option>
                        <option value="appartement">Appartement</option>
                    </select><br>
                    <label for="adresse">Adresse :</label>
                    <input type="text" id="adresse" name="adresse" placeholder="xx rue, code postal VILLE" required><br><br>
                    <label for="exterieur">Extérieur :</label>
                    <input type="checkbox" id="exterieur" name="exterieur" value="oui">
                    <label for="exterieur">Extérieur</label><br><br>
                    <label for="nbHeure">Nombre d'heures où l'animal sera seul par jour :</label>
                    <input type="number" id="nbHeure" name="nbHeure" required><br><br>
                    <label for="enfant">Nombre d'enfants :</label>
                    <input type="number" id="enfant" name="enfant" required><br><br>
                    <label for="motif">Motif de l'adoption :</label>
                    <textarea id="motif" name="motif" placeholder="Motif de l'adoption"></textarea><br><br>
                    <button type="submit">Envoyer</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

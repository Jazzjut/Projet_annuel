<?php //php du formulaire de recherche adoption
require_once("init.php");//Connexion à la base de données
//récupere les valeurs du formulaires
$espece = $_POST["espece"];
$localisation = $_POST["localisation"];
$race = $_POST["race"];

// Initialisation de la requête et preparation
$requete = $db->prepare("SELECT espece, locaP, race FROM Pet WHERE espece = :espece AND locaP = :localisation AND race = :race");
// Liaison des paramètres
$requete->bindParam(':espece', $espece);
$requete->bindParam(':localisation', $localisation);
$requete->bindParam(':race', $race);
// Exécution de la requête
$requete->execute();
// Récupération des résultats
$resultat = $requete->fetch();
// Traitement des résultats
if ($resultats) {
    foreach ($resultats as $resultat) {
        echo "Espèce: " . $resultat["espece"] . ", Localisation: " . $resultat["locaP"] . ", Race: " . $resultat["race"] . "<br>";
    }
} else {
    echo "Aucun animal trouvé pour ces critères de recherche.";
}
?>
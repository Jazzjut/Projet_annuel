<?php
// Connexion à la base de données
require_once("init.php");

// Récupération des valeurs du formulaire
$dateDuJour = $_POST['dateDuJour']
$formDemandeAID = $_POST['formDemandeAID']
$Logement = $_POST['Logement'];
$Adresse = $_POST['Adresse'];
$Extérieur = isset($_POST['Extérieur']) ? $_POST['Extérieur'] : 'non'; // Si la case à cocher est cochée, la valeur sera 'oui', sinon 'non'
$NbHeure = $_POST['NbHeure'];
$Enfant = $_POST['Enfant'];
$Motif = $_POST['Motif'];

// Générer un identifiant unique
$formDemandeAID  = uniqid();

// Obtenir la date actuelle
$dateDuJour = date("Y-m-d");

// Préparation de la requête (premiere ligne les champs, seconde les marqueurs)
$requete = "INSERT INTO FormDemandeA (formDemandeAID, dateDemandeA, Logement, Adresse, ext, nbHSeul, nbEnf, raisonDemandeA)
VALUES (:formDemandeAID, :dateDuJour, :Logement, :Adresse, :Extérieur, :NbHeure, :Enfant, :Motif)";

// Préparation de la requête avec les marqueurs de nom
$ajout = $db->prepare($requete);

// Liaison des valeurs aux marqueurs de nom avec la méthode bindParam()
$ajout->bindParam(':formDemandeAID', $formDemandeAID);
$ajout->bindParam(':dateDuJour', $dateDuJour);
$ajout->bindParam(':Logement', $logement); // Lie la variable $logement au marqueur de nom :Logement
$ajout->bindParam(':Adresse', $adresse); // Lie la variable $adresse au marqueur de nom :Adresse
$ajout->bindParam(':Extérieur', $extérieur); // Lie la variable $extérieur au marqueur de nom :Extérieur
$ajout->bindParam(':NbHeure', $nbHeure); // Lie la variable $nbHeure au marqueur de nom :NbHeure
$ajout->bindParam(':Enfant', $enfant); // Lie la variable $enfant au marqueur de nom :Enfant
$ajout->bindParam(':Motif', $motif); // Lie la variable $motif au marqueur de nom :Motif


// Exécution de la requête 
if ($ajout->execute()) {
    // Vérifiez si des lignes ont été affectées (insérées)
    if ($ajout->rowCount() > 0) {
        echo "Demande d'adoption enregistrée avec succès.";
    } else {
        echo "Erreur: Aucune ligne insérée.";
    }
} else {
    echo "Erreur: " . implode(", ", $ajout->errorInfo());
}

// Fermeture de la connexion à la base de données
$db = null;
?>
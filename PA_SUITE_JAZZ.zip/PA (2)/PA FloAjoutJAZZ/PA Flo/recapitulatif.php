<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Récapitulatif</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-droite">
            <div class="formulaire">
                <h2>Récapitulatif de votre demande d'adoption</h2>
                <?php
                require_once("init.php");
                ini_set('display_errors', 1);
                ini_set('display_startup_errors', 1);
                error_reporting(E_ALL);

                $formDemandeAID = crc32(uniqid());
                $logement = $_POST['Logement'];
                $adresse = $_POST['Adresse'];
                $exterieur = isset($_POST['exterieur']) ? 'Oui' : 'Non';
                $nbHeure = $_POST['NbHeure'];
                $enfant = $_POST['Enfant'];
                $motif = $_POST['Motif'];
                $etat = 'en cours de traitement';
                $date = date("Y-m-d");

                $_SESSION['formDemandeAID'] = $formDemandeAID;
                $_SESSION['logement'] = $logement;
                $_SESSION['adresse'] = $adresse;
                $_SESSION['exterieur'] = $exterieur;
                $_SESSION['nbHeure'] = $nbHeure;
                $_SESSION['enfant'] = $enfant;
                $_SESSION['motif'] = $motif;
                // Traitement des données et requête SQL ici

                // Affichage des données récapitulatives
                echo "<p><strong>Numéro de demande :</strong> $formDemandeAID</p>";
                echo "<p><strong>Date de la demande :</strong> $date</p>";
                echo "<p><strong>Logement :</strong> $logement</p>";
                echo "<p><strong>Adresse :</strong> $adresse</p>";
                echo "<p><strong>Extérieur :</strong> $exterieur</p>";
                echo "<p><strong>Nombre d'heures où l'animal sera seul par jour :</strong> $nbHeure</p>";
                echo "<p><strong>Nombre d'enfants :</strong> $enfant</p>";
                echo "<p><strong>Motif de l'adoption :</strong> $motif</p>";

                // Boutons de validation et d'annulation
                echo "<form class='formulaire' action='traitement.php' method='post'>";
                echo "<button type='submit' name='valider' value='Valider'>Valider</button>";
                echo "<button type='submit' name='annuler' value='Annuler'>Annuler</button>";
                echo "</form>";
                ?>
            </div>
        </div>
    </div>
</body>

</html>
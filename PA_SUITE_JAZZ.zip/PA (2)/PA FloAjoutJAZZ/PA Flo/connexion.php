<?php //php du formulaire de connexion
require_once("init.php");
$pseudo = $_POST["pseudo"];
$mdp = $_POST["mdp"];

$requete = $db->prepare("SELECT pseudoC, mdpC, mailC, telC, nomC, prenomC FROM Client WHERE pseudoC = :pseudo");
$requete->bindParam(':pseudo', $pseudo);
$requete->execute();
$resultat = $requete->fetch();

if ($resultat) {
    if (password_verify($mdp, $resultat["mdpC"])) {
        $_SESSION['mailC'] = $resultat["mailC"];
        $_SESSION['pseudo'] = $pseudo;
        $_SESSION['telC'] = $resultat["telC"];
        $_SESSION['nomC'] = $resultat["nomC"];
        $_SESSION['prenomC'] = $resultat["prenomC"];
        if ($_SESSION['pseudo'] == 'admin') {
            header('Location: admin.php');
        } else {
            echo 'Connecté';
            header('Location: accueil.html');
        }
    } else {
        echo "Mot de passe incorrect.";
    }
} else {
    echo "Utilisateur non trouvé.";
}

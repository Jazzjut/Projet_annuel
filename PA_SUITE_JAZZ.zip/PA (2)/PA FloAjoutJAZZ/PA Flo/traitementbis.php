<?php
require_once("init.php"); // Assurez-vous d'inclure votre fichier d'initialisation

if (isset($_POST['valider'])) {
    $logement = $_SESSION['logement'];
    $adresse = $_SESSION['adresse'];
    $exterieur = $_SESSION['exterieur'];
    $nbHeure = $_SESSION['nbHeure'];
    $enfant = $_SESSION['enfant'];
    $motif = $_SESSION['motif'];
    $etat = 'en cours de traitement';

    $date = date("Y-m-d");

    // Préparation de la requête SQL
    $requete = "INSERT INTO FormDemandeA(Logement, Adresse, ext, nbHSeul, nbEnf, raisonDemandeA, dateDemandeA, etatDemandeA) 
                VALUES (:logement, :adresse, :exterieur, :nbHeure, :enfant, :motif, :date, :etat)";
    $ajout = $db->prepare($requete);

    // Liaison des paramètres
    $ajout->bindParam(':logement', $logement);
    $ajout->bindParam(':adresse', $adresse);
    $ajout->bindParam(':exterieur', $exterieur);
    $ajout->bindParam(':nbHeure', $nbHeure);
    $ajout->bindParam(':enfant', $enfant);
    $ajout->bindParam(':motif', $motif);
    $ajout->bindParam(':etat', $etat);
    $ajout->bindParam(':date', $date);

    // Exécution de la requête
    if ($ajout->execute()) {
        echo "Demande d'adoption enregistrée avec succès.";
    } else {
        echo "Erreur lors de l'enregistrement de la demande d'adoption.";
    }
} elseif (isset($_POST['annuler'])) {
    // Si l'utilisateur clique sur "Annuler", ne rien faire
    echo "La demande d'adoption a été annulée.";
    header("Location: accueil.html");
}
// Fermeture de la connexion à la base de données
$db = null;

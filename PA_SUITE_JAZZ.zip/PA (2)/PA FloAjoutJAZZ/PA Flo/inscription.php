<?php
// php du formulaire d'inscription
require_once("init.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pseudo = $_POST["pseudo"];
$nom = $_POST["nom"];
$prenom = $_POST["prenom"];
$mail = $_POST["mail"];
$mdp = password_hash($_POST["mdp"], PASSWORD_DEFAULT);
$tel = $_POST["tel"];

$requete = "INSERT INTO Client (pseudoC, nomC, prenomC, mailC, telC, mdpC)
    VALUES (:pseudo, :nom, :prenom, :mail, :tel, :mdp)";

try {
    $ajout = $db->prepare($requete);
    $ajout->bindParam(':pseudo', $pseudo);
    $ajout->bindParam(':nom', $nom);
    $ajout->bindParam(':prenom', $prenom);
    $ajout->bindParam(':mail', $mail);
    $ajout->bindParam(':tel', $tel);
    $ajout->bindParam(':mdp', $mdp);

    if ($ajout->execute()) {
        if ($ajout->rowCount() > 0) {
            header("Location: accueil.html");
            exit;
        } else {
            echo "Erreur lors de l'inscription.";
        }
    } else {
        echo "Erreur lors de l'inscription.";
    }
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        echo "L'adresse e-mail et le pseudo doivent être uniques. Veuillez réessayer.";
    } else {
        echo "Erreur : " . $e->getMessage();
    }
}

// Fermer la connexion à la base de données
$db = null;

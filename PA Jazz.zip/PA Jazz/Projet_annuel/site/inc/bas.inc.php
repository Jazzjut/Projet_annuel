        <footer>
            <div>    
                <?php echo date('Y'); ?> - Tous droits reservés - Pattes en détresses.
            </div>
        </footer>

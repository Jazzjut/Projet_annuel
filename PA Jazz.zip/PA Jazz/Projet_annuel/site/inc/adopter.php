
            <!--barre de recherche peut être juste le mettre dans adoption ou adopter-->

            <form role="search">
                <div>
            <input 
                    type="search"
                    name="text" 
                    class="search" 
                    placeholder="Recherchez ici!"
                    aria-label="Rechercher parmi le contenu du site"/>
            <input 
                    type="submit" 
                    name="submit" 
                    class="submit" 
                    value="Search"/>
                </div>
            </form>
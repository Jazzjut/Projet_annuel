<!DOCTYPE HTML>
<html>
    
    <head>
        <meta charset="utf-8" />
        <link href="style.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <?php include("menu.php")?><br><br>
        <form method="post" action="inscription2.php">
        <label for="pseudo">Pseudo</label><br>
        <input type="text" id="pseudo" name="pseudo" maxlength="20" placeholder="Votre Pseudo" pattern="[a-zA-Z0-9-_.]{1,20}" title="caractères acceptés : a-zA-Z0-9-_." required="required"><br><br>

        <label for="mdp">Mot de passe</label><br>
        <input type="password" id="mdp" name="mdp" placeholder="Votre mot de passe" required="required"><br><br>

        <label for="nom">Nom</label><br>
        <input type="text" id="nom" name="nom" placeholder="Votre nom" required="required"><br><br>

        <label for="prenom">Prénom</label><br>
        <input type="text" id="prenom" name="prenom" placeholder="Votre prénom" required="required"><br><br>

        <label for="mail">Adresse mail</label><br>
        <input type="mail" id="mail" name="mail" placeholder="exemple@gmail.com" required="required"><br><br>

        <label for="tel">Numéro de téléphone</label><br>
        <input type ="text" id="tel" name="tel" placeholder="06XXXXXXXX" pattern ="[0-9]{10}" title="10 chiffres requis : 0-9" required="required"><br><br>

        <input type="submit" name="inscription" value="S'inscrire">
        </form>
    </body>
</html>
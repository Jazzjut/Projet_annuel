<!DOCTYPE html>
    <head>
        <title>Pattesendétresses</title>
        <meta charset="utf-8">
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>
<div id="menu">
        <div>

            <!--Bouton-->

            <button class="bouton">
                <a href="accueil.php" class="no-underline">Accueil</a></button><br><br>
            <button class="bouton">
                <a href="moncompte.php" class="no-underline">Se connecter/S'inscrire</a></button><br><br>
            <button class="bouton">
                <a href="adopter.php" class="no-underline"> Adopter un animal</a></button><br><br>
            <button class="bouton">
                <a href="donner.php" class="no-underline"> Mettre à l'adoption</a></button><br><br>
            <button class="bouton">
                <a href="don.php" class="no-underline"> Faire un don</a></button><br><br>

        </div>
</div>
</html>

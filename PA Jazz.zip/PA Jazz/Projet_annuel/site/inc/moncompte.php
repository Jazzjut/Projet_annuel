<!DOCTYPE html>
    <head>
        <title>Pattesendétresses</title>
        <meta charset="utf-8">
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <?php include("menu.php");?>
        <div>
            <h1>Se connecter/S'inscrire</h1>
            <button class="bouton"><a href="connexion.php" class="no-underline">Connexion</a></button><br><br>
            <button class="bouton"><a href="inscription.php" class="no-underline">Inscription</a></button><br><br>
        <?php include("bas.inc.php"); ?>
    </body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>Pattes en détresses</title>
	<meta charset="utf-8">
	<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
	<?php include("menu.php");?>
	<div id="corps">
		<h1>Pattes en détresses</h1>
		<p>
			Bienvenue humain<br/>
			Voici le paradis des chats et des chiens!
		</p>
	</div>
	<?php include("bas.inc.php");?>
</body>
</html>
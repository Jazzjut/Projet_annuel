<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8" />
        </head>
        <body>
        <?php include("menu.php")?>
        <form method="post" action="connexion2.php">
            <label for="pseudo">Pseudo</label>
            <input type="pseudo" id="pseudo" name="pseudo" placeholder="Votre Pseudo" required="required"><br><br>

            <label for="mdp">Mot de passe</label>
            <input type="password" id="mdp" name="mdp" placeholder="Votre mot de passe" required="required"><br><br>

            <input type="submit" name="connexion" value="Se connecter">
            </form>
        </body>
</html>
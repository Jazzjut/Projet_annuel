<!Doctype html>
<html>
    <head>
    <title>Pattes en détresses</title>
    <link rel="stylesheet" href="<?php echo RACINE_SITE; ?>inc/css/style.css">
    </head>
    <body>
        <header>
            <div
            class="conteneur">
            <div>
                <a href=""title="Pattes en détresses">Patteseendétresse.com</a>
</div>
<nav>
    <a href="<?php echo RACINE_SITE; ?>inscription.php">Inscription</a>
    <a href="<?php echo RACINE_SITE; ?>connexion.php">Connexion</a>
    <a href="<?php echo RACINE_SITE; ?>animalerie.php">Accès à l'animalerie</a>
</nav>
</div>
</header>
<section>
    <div class="conteneur">
    
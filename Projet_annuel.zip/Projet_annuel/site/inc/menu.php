<div id="menu">
        <div class="element_menu">
            <h3>Menu</h3>
            <ul>
            <a href="connexion.php">Connexion</a><br>
            <a href="inscription.php">Inscription</a>
            </ul>
        </div>
</div>
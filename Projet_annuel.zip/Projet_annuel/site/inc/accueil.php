<!DOCTYPE html>
    <head>
        <title>Pattesendétresses</title>
    </head>
    <body>
        <?php include("menu.php"); ?>
        <div id="corps">
            <h1>Pattes en détresses</h1>
            <p>
                Bienvenue sur mon site<br />
                bla, bla, bla…
            </p>
        </div>
        <?php include("bas.inc.php"); ?>
    </body>
</html>

<?php
$host = "10.16.140.38"
$database = jjutea02
$username = jjutea02
$password = 22000638
try{
$db = new PDO("mysql:host=localhost" . $host . ";dbname=jjuteau02" . $database, $username,$password);
}
catch(PDOException $e){
die("<h1>Impossible de ce connecter a la base de données:</h1>" .$e);
}
// $mysqli->set_charset("utf8");
//--------- SESSION
session_start();

//--------- CHEMIN
define("RACINE_SITE","/site/");

//--------- VARIABLES
$contenu = '';

//--------- AUTRES INCLUSIONS
require_once("fonction.inc.php");
?>

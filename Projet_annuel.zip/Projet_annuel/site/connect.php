<?php
$host = "localhost";
$database = "jjutea02";
$username = "jjutea02";
$password = "22000638";
try{
$db = new PDO("mysql:host=".$host.";dbname=".$database,$username,$password);
}
catch(PDOException $e){
die("<h1>Impossible de ce connecter a la base de données:</h1>" .$e);
}
?>

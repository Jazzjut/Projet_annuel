<div id="menu">
        <div>
            <h3>Menu</h3>

            <!--Bouton-->

            <button class="bouton">
                <a href="accueil.php">Accueil</a></button><br><br>
            <button class="bouton">
                <a href="moncompte.php">Se connecter/S'inscrire</a></button><br><br>
            <button class="bouton">
                <a href="adopter.php">> Adopter un animal</a></button><br><br>
            <button class="bouton">
                <a href="donner.php">> Mettre à l'adoption</a></button><br><br>
            <button class="bouton">
                <a href="don.php">> Faire un don</a></button><br><br>

        </div>
</div>
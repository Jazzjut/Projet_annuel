<?php
// Démarrez la session
require_once("init.php");
echo $_SESSION['pseudo'];
// Déterminez si l'utilisateur est connecté
$connecte = isset($_SESSION['pseudo']);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pattes en détresse</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-gauche">
            <div class="logo">
                <img src="Logo.png" alt="Logo" />
            </div>
            <div class="bouton">
                <!-- Lien vers Mon compte, redirigé en fonction de l'état de connexion -->
                <a href="<?php echo $connecte ? 'moncompte.php' : 'compte.php' ?>"><button>Mon compte</button></a>
                <a href="admin.php"><button>Accueil</button></a>
                <!-- Lien vers Adopter un animal, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'formulaires.php' : 'compte.php'; ?>"><button>Formulaires</button></a>
                <!-- Lien vers Mettre à l'adoption, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'visudon.php' : 'compte.php'; ?>"><button>Don</button></a>
                <!-- Lien vers Faire un don, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'animaux.php' : 'compte.php'; ?>"><button>Animaux</button></a>
            </div>
        </div>
        <div class="partie-droite">
        </div>
    </div>
</body>

</html>
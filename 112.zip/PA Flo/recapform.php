<?php
// Inclure le fichier d'initialisation
require_once("init.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$connecte = isset($_SESSION['pseudo']);
// Vérifier si l'ID et le type ont été transmis
if (isset($_GET['id']) && isset($_GET['type'])) {
    $id = $_GET['id'];
    $type = $_GET['type'];

    // Récupérer les détails de la demande en fonction du type
    if ($type == 'demande') {
        $table = 'FormDemandeA';
        $query_details = "SELECT * FROM $table WHERE formDemandeAID = :id";
        $stmt = $db->prepare($query_details);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row_details = $stmt->fetch(PDO::FETCH_ASSOC);
    } elseif ($type == 'mise') {
        $table = 'FormMiseA';
        $query_details = "SELECT * FROM $table WHERE formMiseAID = :id";
        $stmt = $db->prepare($query_details);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row_details = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Récapitulatif</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-gauche">
            <div class="logo">
                <img src="Logo.png" alt="Logo" />
            </div>
            <div class="bouton">
                <!-- Lien vers Mon compte, redirigé en fonction de l'état de connexion -->
                <a href="<?php echo $connecte ? 'moncompte.php' : 'compte.php' ?>"><button>Mon compte</button></a>
                <a href="admin.php"><button>Accueil</button></a>
                <!-- Lien vers Adopter un animal, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'formulaires.php' : 'compte.php'; ?>"><button>Formulaires</button></a>
                <!-- Lien vers Mettre à l'adoption, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'visudon.php' : 'compte.php'; ?>"><button>Don</button></a>
                <!-- Lien vers Faire un don, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'animaux.php' : 'compte.php'; ?>"><button>Animaux</button></a>
            </div>
        </div>
        <div class="partie-droite">
            <div class="formulaire">
                <h2>Récapitulatif de la demande</h2>
                <?php if (isset($row_details)) : ?>
                    <p>Type: <?php echo ucfirst($type); ?></p>
                    <p>Numéro d'ID: <?php echo $id; ?></p>
                    <?php if ($type == 'demande') : ?>
                        <p>Date de la demande: <?php echo $row_details['dateDemandeA']; ?></p>
                        <p>Raison de la demande: <?php echo $row_details['raisonDemandeA']; ?></p>
                        <p>Logement: <?php echo $row_details['Logement']; ?></p>
                        <p>Adresse: <?php echo $row_details['Adresse']; ?></p>
                        <p>Nombre d'enfants: <?php echo $row_details['nbEnf']; ?></p>
                        <p>Nombre d'heures où l'animal sera seul: <?php echo $row_details['nbHSeul']; ?></p>
                        <p>Extérieur: <?php echo $row_details['ext']; ?></p>
                        <p>Mail du demandeur: <?php echo $row_details['mailC']; ?></p>
                    <?php elseif ($type == 'mise') : ?>
                        <p>Date de mise à l'adoption: <?php echo $row_details['dateMiseA']; ?></p>
                        <p>Raison de la mise à l'adoption: <?php echo $row_details['raisonMiseA']; ?></p>
                        <p>Mail du demandeur: <?php echo $row_details['mailC']; ?></p>
                    <?php endif; ?>
                    <!-- Lien vers la page de l'animal -->
                    <p><a href="animal.php?id=<?php echo $row_details['petID']; ?>">Voir l'animal</a></p>
                    <!-- Ajoutez le formulaire de traitement ici -->
                    <form class="formulaire" action="traiteform.php" method="post">
                        <button type="submit" name="accepter">Accepter</button>
                        <button type="submit" name="refuser">Refuser</button>
                    </form>
                <?php else : ?>
                    <p>Demande non trouvée</p>
                <?php endif; ?>
            </div>
        </div>
</body>

</html>
<?php
// Démarrez la session
require_once("init.php");
echo $_SESSION['pseudo'];
// Déterminez si l'utilisateur est connecté
$connecte = isset($_SESSION['pseudo']);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pattes en détresse</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-gauche">
            <div class="logo">
                <img src="Logo.png" alt="Logo" />
            </div>
            <div class="bouton">
                <!-- Lien vers Mon compte, redirigé en fonction de l'état de connexion -->
                <a href="<?php echo $connecte ? 'moncompte.php' : 'compte.php' ?>"><button>Mon compte</button></a>
                <a href="accueil.php"><button>Accueil</button></a>
                <!-- Lien vers Adopter un animal, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'adoption.php' : 'compte.php'; ?>"><button>> Adopter un animal</button></a>
                <!-- Lien vers Mettre à l'adoption, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'formulairemiseadoption.html' : 'compte.php'; ?>"><button>> Mettre à l'adoption</button></a>
                <!-- Lien vers Faire un don, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'don.php' : 'compte.php'; ?>"><button>> Faire un don</button></a>
            </div>
            <div class="formulaire">
                <!-- Recherche avec les filtres -->
                <form action="recherche.php" method="post">
                    <!-- chercher prenom -->
                    <input type="text" name="race" class="champ-race" placeholder="Prénom" /><select name="espece">
                        <option value="">Sélectionnez l'espèce</option>
                        <option value="Chien">Chien</option>
                        <option value="Chat">Chat</option>
                    </select>
                    <select name="race">
                        <option value="">Sélectionnez la race</option>
                        <!-- rajouter d'autre option ex = si la base de données posséde un chat de la race Angora faudrait qu'elle se mette automatiquement dedans -->
                    </select>
                    <select name="sexe">
                        <option value="">Sélectionnez le sexe</option>
                        <option value="Mâle">Mâle</option>
                        <option value="Femelle">Femelle</option>
                    </select>
                    <select name="age">
                        <option value="">Sélectionnez l'age</option>
                        <option value="Junior">Junior</option>
                        <option value="Adulte">Adulte</option>
                        <option value="Senior">Sénior</option>
                    </select>
                    <select name="localisation">
                        <option value="">Sélectionnez la localisation</option>
                        <option value="Poitiers">Poitiers</option>
                        <option value="Toulouse">Toulouse</option>
                        <option value="Lyon">Lyon</option>
                        <option value="Paris">Paris</option>
                        <option value="Clermont-Ferrand">Clermont-Ferrand</option>
                        <option value="Strasbourg">Strasbourg</option>
                    </select>

                    <!-- class="champ-race" => pour qu'il fasse la même taille en largeur que les menus déroulants mais sa na pas fonctionné  -->
                    <button type="submit">Rechercher</button>
                </form>
            </div>
        </div>
        <div class="partie-droite">
            <div class="presentation-animaux">
                <div class="animal">
                    <!--ajouter un animal comme ça pour l'instant-->
                    <img src="export.php?id=1" />
                    <!-- afficher une image qui viens de la bdd -->
                    <div class="bouton2">
                        <a href="fichedescriptif.php">
                            <h3>Bernard</h3>
                        </a>
                    </div>
                    <p>Sexe: Mâle</p>
                </div>
                <div class="animal">
                    <img src="export.php?id=2" />
                    <!-- afficher une image qui viens de la bdd -->
                    <div class="bouton2">
                        <a href="fichedescriptif.php">
                            <h3>Fifi</h3>
                        </a>
                    </div>
                    <p>Sexe: Femelle</p>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
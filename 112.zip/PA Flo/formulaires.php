<?php
// Inclure le fichier d'initialisation
require_once("init.php");
$connecte = isset($_SESSION['pseudo']);
// Récupérer les demandes d'adoption de la table FormDemandeA
$query_demandesA = "SELECT * FROM FormDemandeA";
$stmt_demandesA = $db->query($query_demandesA);
$result_demandesA = $stmt_demandesA->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les mises à l'adoption de la table FormMiseA
$query_misesA = "SELECT * FROM FormMiseA";
$stmt_misesA = $db->query($query_misesA);
$result_misesA = $stmt_misesA->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Liste des formulaires</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-gauche">
            <div class="logo">
                <img src="Logo.png" alt="Logo" />
            </div>
            <div class="bouton">
                <!-- Lien vers Mon compte, redirigé en fonction de l'état de connexion -->
                <a href="<?php echo $connecte ? 'moncompte.php' : 'compte.php' ?>"><button>Mon compte</button></a>
                <a href="admin.php"><button>Accueil</button></a>
                <!-- Lien vers Adopter un animal, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'formulaires.php' : 'compte.php'; ?>"><button>Formulaires</button></a>
                <!-- Lien vers Mettre à l'adoption, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'visudon.php' : 'compte.php'; ?>"><button>Don</button></a>
                <!-- Lien vers Faire un don, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'animaux.php' : 'compte.php'; ?>"><button>Animaux</button></a>
            </div>
        </div>
        <div class="partie-droite">
            <div class="formulaire-adoption">
                <h3>Demandes d'adoption</h3>
                <?php
                // Afficher les demandes d'adoption
                foreach ($result_demandesA as $row_demandeA) {
                    echo "<a href='recapform.php?type=demande&id=" . $row_demandeA['formDemandeAID'] . "'>Demande d'adoption</a>";
                    echo "<p>Numéro d'ID: " . $row_demandeA['formDemandeAID'] . "</p>";
                }
                ?>
            </div>
            <div class="formulaire-mise">
                <h3>Mises à l'adoption</h3>
                <?php
                // Afficher les mises à l'adoption
                foreach ($result_misesA as $row_miseA) {
                    echo "<a href='recapform.php?type=mise&id=" . $row_miseA['formMiseAID'] . "'>Mise à l'adoption</a>";
                    echo "<p>Numéro d'ID: " . $row_miseA['formMiseAID'] . "</p>";
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>
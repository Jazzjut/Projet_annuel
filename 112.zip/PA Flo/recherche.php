<?php //php du formulaire de recherche adoption
require_once("init.php"); //Connexion à la base de données

//récupere les valeurs du formulaires
$espece = $_POST["espece"];
$race = $_POST["race"];
$sexe = $_POST["sexe"];
$age = $_POST["age"];
$localisation = $_POST["localisation"];

// Initialisation de la requête et preparation
$requete = $db->prepare("SELECT espece, race, sexe, age, locaP FROM Pet WHERE espece = :espece AND  race = :race AND sexe = :sexe AND age = :age AND locaP = :localisation");

// Liaison des paramètres
$requete->bindParam(':espece', $espece);
$requete->bindParam(':race', $race);
// compliqué car il faut que la race de l'animal si présente dans la bases de données apparaisent directement dans le menu déroulant 
$requete->bindParam(':sexe', $sexe);

if ($Age) {
    switch ($age) {
        case "Junior":
            $minAge = 0;
            $maxAge = 2;
            break;
        case "Adulte":
            $minAge = 3;
            $maxAge = 10;
            break;
        case "Senior":
            $minAge = 11;
            //$maxAge = int_max; //valeurs max de l'age
            break;
        default:
            $minAge = 0;
            //$maxAge = integer;
            break;
    }
}
// Ajouter la condition d'âge à la requête
$requete->bindParam(':min_age', $minAge);
$requete->bindParam(':max_age', $maxAge);

// compliqué car c'est une borne d'age junior de 0 à 3, Adulte de 3 à 10 et Senior de 10 à plus
$requete->bindParam(':localisation', $localisation);

// Exécution de la requête
$requete->execute();

// Récupération des résultats
$resultat = $requete->fetch();

// Traitement des résultats
if ($resultats) {
    foreach ($resultats as $resultat) {
        echo "Espèce: " . $resultat["espece"] . ", race: " . $resultat["race"] . "Sexe: " . $resultat["sexe"] . "Age: " . $resultat["Age"] . ", Localisation: " . $resultat["locaP"] . "<br>";
    }
} else {
    echo "Aucun animal trouvé pour ces critères de recherche.";
}

<?php
// Démarrez la session
require_once("init.php");
echo $_SESSION['pseudo'];
// Déterminez si l'utilisateur est connecté
$connecte = isset($_SESSION['pseudo']);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pattes en détresse</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-gauche">
            <div class="logo">
                <img src="Logo.png" alt="Logo" />
            </div>
            <div class="bouton">
                <!-- Lien vers Mon compte, redirigé en fonction de l'état de connexion -->
                <a href="<?php echo $connecte ? 'moncompte.php' : 'compte.php' ?>"><button>Mon compte</button></a>
                <a href="accueil.php"><button>Accueil</button></a>
                <!-- Lien vers Adopter un animal, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'adoption.php' : 'compte.php'; ?>"><button>> Adopter un animal</button></a>
                <!-- Lien vers Mettre à l'adoption, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'formulairemiseadoption.html' : 'compte.php'; ?>"><button>> Mettre à l'adoption</button></a>
                <!-- Lien vers Faire un don, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'don.php' : 'compte.php'; ?>"><button>> Faire un don</button></a>
            </div>
        </div>
        <div class="partie-droite">
            <div class="formulaire">
                <h2>S'inscrire</h2>
                <form action="inscription.php" method="post">
                    <input type="text" id="pseudo" name="pseudo" maxlength="20" placeholder="Votre Pseudo" pattern="[a-zA-Z0-9-_.]{1,20}" title="caractères acceptés : a-zA-Z0-9-_." required>
                    <input type="mail" id="mail" name="mail" placeholder="exemple@gmail.com" required>
                    <input type="password" id="mdp" name="mdp" placeholder="Votre mot de passe" required>
                    <input type="text" id="nom" name="nom" placeholder="Votre nom" required>
                    <input type="text" id="prenom" name="prenom" placeholder="Votre prénom" required>
                    <input type="text" id="tel" name="tel" placeholder="06XXXXXXXX" pattern="[0-9]{10}" title="10 chiffres requis : 0-9" required>
                    <button type="submit">S'inscrire</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
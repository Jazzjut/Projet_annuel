<?php
// Démarrez la session
require_once("init.php");
echo $_SESSION['pseudo'];
// Déterminez si l'utilisateur est connecté
$connecte = isset($_SESSION['pseudo']);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pattes en détresse</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="container">
        <div class="partie-gauche">
            <div class="logo">
                <img src="Logo.png" alt="Logo" />
            </div>
            <div class="bouton">
                <!-- Lien vers Mon compte, redirigé en fonction de l'état de connexion -->
                <a href="<?php echo $connecte ? 'moncompte.php' : 'compte.php' ?>"><button>Mon compte</button></a>
                <a href="accueil.php"><button>Accueil</button></a>
                <!-- Lien vers Adopter un animal, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'adoption.php' : 'compte.php'; ?>"><button>> Adopter un animal</button></a>
                <!-- Lien vers Mettre à l'adoption, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'formulairemiseadoption.html' : 'compte.php'; ?>"><button>> Mettre à l'adoption</button></a>
                <!-- Lien vers Faire un don, redirigé vers connexion.html si non connecté -->
                <a href="<?php echo $connecte ? 'don.php' : 'compte.php'; ?>"><button>> Faire un don</button></a>
            </div>
        </div>
        <div class="partie-droite">
                <div class="presanimal">
                    <div class="presentation-animaux">
                        <div class="animal">
                            <img src="animal1.jpg" alt="Animal 1">
                        </div>
                        <div class="texte">
                            <p>Bernard<p>
                            <p>Age:</p><p>ans</p>
                            <p>Race :</p>
                            <p>Espèce :</p>
                            <p>Sexe :</p>
                            <p>Refuge :</p>
                            <p>Description:</p><p>Bernard est de nature plutôt calme qui s'entend avec ses congénères. Il est castré, pucé et ses vaccins sont à jour.</p>
                            <div bouton><a href="formulaireadoptionbis.php"><button><h3>Adoptez-moi</h3></button></a></div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</body>
</html>
